// Six more home-screen variations, each blending real-estate UX with the
// Living Tree brand. All use the real project facts from kalyanidevelopers.com.

const PROJECT = {
  name: "LivingTree",
  by: "Kalyani Developers",
  loc: "KIADB Aerospace Park · Bagalur · North Bengaluru",
  airport: "15 min · Kempegowda Int'l Airport",
  acres: "25",
  towers: "10",
  units: "2,522",
  floors: "G + 23",
  config: "1 · 2 · 2.5 · 3 BHK",
  sizeFrom: "576",
  sizeTo: "1,927",
  priceFrom: "₹48.9 L*",
  priceTo: "₹1.52 Cr",
  amen: "60+",
  open: "80% open",
  poss: "Sep 2029",
  rera: "PRM/KA/RERA/1251/309/PR/260924/007084",
  estd: "1991",
};

const BHK_DATA = [
  { tag: "1 BHK", size: "576 sqft",      price: "from ₹48.9 L*",  units: "404 units" },
  { tag: "2 BHK", size: "1,041–1,054",   price: "from ₹75.0 L*",  units: "892 units" },
  { tag: "2.5",   size: "1,135–1,143",   price: "from ₹82.0 L*",  units: "586 units" },
  { tag: "3 BHK", size: "1,316–1,927",   price: "from ₹1.21 Cr*", units: "640 units" },
];

// ============================================================
// VARIANT 5 — Sales Console: Concierge-grade dashboard
// ============================================================
const VariantConsole = () => {
  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif",
      background: "#faf6ec", color: "#1c2520",
    }}>
      {/* organic leaf watermark */}
      <svg style={{ position: "absolute", right: -120, top: -80, width: 720, height: 720, opacity: 0.06 }} viewBox="0 0 200 200">
        <path d="M40 160 C40 80 100 30 180 30 C180 110 130 160 40 160 Z" fill="#2c4030"/>
        <path d="M40 160 L160 50" stroke="#2c4030" strokeWidth="1.5" fill="none"/>
      </svg>

      <StatusBar />

      {/* topbar */}
      <div style={{
        position: "absolute", top: 50, left: 56, right: 56,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <LivingTreeMark size={38} color="#2c4030" />
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, fontWeight: 500, lineHeight: 1 }}>
              Living<em style={{ fontStyle: "italic", color: "#a85a32" }}>Tree</em>
            </div>
            <div style={{ fontSize: 10, letterSpacing: 2, opacity: 0.55, textTransform: "uppercase", marginTop: 3 }}>
              by Kalyani Developers · est. {PROJECT.estd}
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            padding: "8px 14px", border: "1px solid rgba(28,37,32,0.18)",
            borderRadius: 999, fontSize: 11, letterSpacing: 1.6, textTransform: "uppercase",
          }}>RERA · {PROJECT.rera.slice(0, 24)}…</div>
          <div style={{
            display: "flex", alignItems: "center", gap: 10, padding: "6px 14px 6px 6px",
            background: "#2c4030", color: "#faf6ec", borderRadius: 999,
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: "50%",
              background: "linear-gradient(135deg, #d9b27a, #b9874a)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 13, fontWeight: 600, color: "#1c2520",
            }}>PR</div>
            <div style={{ lineHeight: 1.1 }}>
              <div style={{ fontSize: 12, fontWeight: 600 }}>Priya Rao</div>
              <div style={{ fontSize: 10, opacity: 0.7, letterSpacing: 0.5 }}>Your advisor · today</div>
            </div>
          </div>
        </div>
      </div>

      {/* hero stat bar */}
      <div style={{
        position: "absolute", top: 134, left: 56, right: 56,
        background: "white",
        borderRadius: 14,
        padding: "26px 32px",
        display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr 1fr",
        gap: 28, alignItems: "center",
        boxShadow: "0 18px 40px rgba(28,37,32,0.06)",
        border: "1px solid rgba(28,37,32,0.06)",
      }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.55, textTransform: "uppercase" }}>Starting at</div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 44, fontWeight: 500, lineHeight: 1, marginTop: 2 }}>
            {PROJECT.priceFrom}
          </div>
          <div style={{ fontSize: 11, opacity: 0.55, marginTop: 4 }}>1 BHK · 576 sqft · onwards</div>
        </div>
        {[
          ["Configurations", PROJECT.config],
          ["Land · Towers", `${PROJECT.acres} acres · ${PROJECT.towers}`],
          ["Total homes", PROJECT.units],
          ["Possession", PROJECT.poss],
        ].map(([k, v]) => (
          <div key={k} style={{ borderLeft: "1px solid rgba(28,37,32,0.1)", paddingLeft: 22 }}>
            <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.55, textTransform: "uppercase" }}>{k}</div>
            <div style={{ fontSize: 19, fontWeight: 600, marginTop: 6, letterSpacing: -0.2 }}>{v}</div>
          </div>
        ))}
      </div>

      {/* centerpiece title */}
      <div style={{ position: "absolute", top: 286, left: 0, right: 0, textAlign: "center" }}>
        <div style={{ fontSize: 11, letterSpacing: 5, opacity: 0.55, textTransform: "uppercase" }}>
          {PROJECT.loc}
        </div>
        <h1 style={{
          fontFamily: "'Cormorant Garamond', serif", fontWeight: 400, fontSize: 64,
          margin: "12px 0 6px", lineHeight: 1, letterSpacing: -0.5,
        }}>
          Walk through your <em style={{ fontStyle: "italic", color: "#a85a32" }}>future home</em>.
        </h1>
        <div style={{ fontSize: 14, opacity: 0.6, letterSpacing: 0.2 }}>
          Tap any circle to begin · {PROJECT.airport}
        </div>
      </div>

      {/* circle menu */}
      <div style={{
        position: "absolute", bottom: 200, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 48,
      }}>
        {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => (
          <div key={key} style={{ textAlign: "center", width: 200 }}>
            <div style={{
              width: 148, height: 148, borderRadius: "50%",
              background: "white",
              border: "1px solid rgba(28,37,32,0.08)",
              display: "flex", alignItems: "center", justifyContent: "center",
              margin: "0 auto",
              boxShadow: "0 16px 36px rgba(28,37,32,0.08), inset 0 1px 0 rgba(255,255,255,0.9)",
              position: "relative",
            }}>
              <Icon size={58} stroke="#2c4030" strokeWidth={1.3} />
              <div style={{
                position: "absolute", top: 10, right: 14, width: 8, height: 8,
                borderRadius: "50%", background: "#a85a32",
              }}/>
            </div>
            <div style={{ marginTop: 16, fontSize: 16, fontWeight: 600, letterSpacing: 0.2 }}>{label}</div>
            <div style={{ marginTop: 3, fontSize: 11.5, opacity: 0.55 }}>{hint}</div>
          </div>
        ))}
      </div>

      {/* CTAs */}
      <div style={{
        position: "absolute", bottom: 60, left: 56, right: 56,
        display: "flex", justifyContent: "space-between", alignItems: "center",
      }}>
        <div style={{ display: "flex", gap: 12 }}>
          <button style={{
            background: "#2c4030", color: "#faf6ec", border: "none",
            padding: "16px 28px", borderRadius: 999, fontSize: 14, fontWeight: 600,
            letterSpacing: 0.4, cursor: "pointer",
          }}>Schedule site visit →</button>
          <button style={{
            background: "transparent", color: "#1c2520",
            border: "1px solid rgba(28,37,32,0.25)",
            padding: "16px 28px", borderRadius: 999, fontSize: 14, fontWeight: 500,
            letterSpacing: 0.4, cursor: "pointer",
          }}>Download brochure</button>
        </div>
        <div style={{ display: "flex", gap: 28, fontSize: 11.5, letterSpacing: 1.5, textTransform: "uppercase", opacity: 0.6 }}>
          <span><b style={{ color: "#a85a32" }}>6</b> advisors on floor</span>
          <span><b style={{ color: "#a85a32" }}>24</b> enquiries today</span>
          <span><b style={{ color: "#a85a32" }}>402</b> homes sold</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 6 — Tower Selector: visualize the 10 towers
// ============================================================
const VariantTowers = () => {
  // 10 towers, each with G+23 floors. Show as silhouettes with sold/available dots.
  const towers = Array.from({ length: 10 }, (_, i) => ({
    id: `T${String(i + 1).padStart(2, "0")}`,
    floors: 24,
    sold: Math.floor(40 + Math.sin(i * 1.7) * 20),
    phase: i < 6 ? 1 : 2,
  }));

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif", color: "#f4eedb",
      background: "linear-gradient(180deg, #2a3a30 0%, #1a2620 50%, #101814 100%)",
    }}>
      {/* subtle horizon glow */}
      <div style={{
        position: "absolute", left: 0, right: 0, top: "55%", height: 200,
        background: "radial-gradient(ellipse at center, rgba(217,178,122,0.18), transparent 70%)",
      }} />

      <StatusBar light />

      {/* top */}
      <div style={{
        position: "absolute", top: 54, left: 64, right: 64,
        display: "flex", justifyContent: "space-between", alignItems: "flex-start",
      }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: 5, opacity: 0.55, textTransform: "uppercase" }}>
            Kalyani Developers · Bagalur
          </div>
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontSize: 40, fontWeight: 500,
            letterSpacing: 0.6, marginTop: 6, lineHeight: 1,
          }}>
            Living<em style={{ fontStyle: "italic", color: "#d9b27a" }}>Tree</em>
            <span style={{ fontSize: 14, fontFamily: "Inter, sans-serif", letterSpacing: 4, marginLeft: 18, opacity: 0.6 }}>
              · 10 TOWERS · 2,522 HOMES
            </span>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.55, textTransform: "uppercase" }}>From</div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 32, fontWeight: 500, lineHeight: 1, color: "#d9b27a", marginTop: 4 }}>
            {PROJECT.priceFrom}
          </div>
          <div style={{ fontSize: 11, opacity: 0.6, marginTop: 3 }}>
            Possession {PROJECT.poss}
          </div>
        </div>
      </div>

      {/* skyline */}
      <div style={{
        position: "absolute", left: 64, right: 64, top: 200, bottom: 360,
        display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 8,
      }}>
        {towers.map((t, i) => {
          const h = 360 + (i % 3) * 22 - Math.abs(i - 4) * 8;
          const w = 56;
          return (
            <div key={t.id} style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}>
              <div style={{
                fontSize: 9, letterSpacing: 2, opacity: 0.55, textTransform: "uppercase", marginBottom: 10,
              }}>{t.id} · P{t.phase}</div>

              <div style={{
                width: w, height: h, position: "relative",
                background: "linear-gradient(180deg, rgba(244,238,219,0.16) 0%, rgba(244,238,219,0.04) 100%)",
                border: "1px solid rgba(244,238,219,0.15)",
                borderRadius: "3px 3px 0 0",
              }}>
                {/* floor windows */}
                {Array.from({ length: 24 }).map((_, f) => {
                  const isSold = f < (24 * t.sold / 100);
                  return (
                    <div key={f} style={{
                      position: "absolute", left: 6, right: 6,
                      bottom: f * (h - 20) / 24 + 6,
                      height: (h - 20) / 24 - 4,
                      display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 2,
                    }}>
                      {[0,1,2].map(w => (
                        <div key={w} style={{
                          background: isSold
                            ? "rgba(217,178,122,0.55)"
                            : "rgba(244,238,219,0.12)",
                          height: "100%",
                        }} />
                      ))}
                    </div>
                  );
                })}
              </div>

              <div style={{ fontSize: 10, opacity: 0.65, marginTop: 8 }}>
                {t.sold}% sold
              </div>
            </div>
          );
        })}
      </div>

      {/* ground line */}
      <div style={{
        position: "absolute", left: 0, right: 0, bottom: 350, height: 1,
        background: "rgba(217,178,122,0.3)",
      }}/>

      {/* legend */}
      <div style={{
        position: "absolute", left: 64, bottom: 310,
        display: "flex", gap: 22, fontSize: 11, letterSpacing: 1.5, opacity: 0.7,
      }}>
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 12, height: 12, background: "rgba(217,178,122,0.55)", borderRadius: 2 }} /> Sold
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 12, height: 12, background: "rgba(244,238,219,0.12)", border: "1px solid rgba(244,238,219,0.3)", borderRadius: 2 }} /> Available
        </span>
        <span>· Phase 1: T01–T06 · ready late 2028</span>
      </div>

      {/* menu band */}
      <div style={{
        position: "absolute", left: 64, right: 64, bottom: 60,
        background: "rgba(244,238,219,0.04)",
        border: "1px solid rgba(244,238,219,0.12)",
        borderRadius: 18, backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
        padding: 28,
        display: "grid", gridTemplateColumns: "auto 1fr", gap: 36, alignItems: "center",
      }}>
        <div style={{ maxWidth: 220 }}>
          <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.6, textTransform: "uppercase" }}>Begin</div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, marginTop: 6, lineHeight: 1.1 }}>
            Step into the residence.
          </div>
        </div>
        <div style={{ display: "flex", gap: 18, justifyContent: "space-between" }}>
          {MENU_ITEMS.map(({ key, label, hint, Icon }) => (
            <div key={key} style={{ display: "flex", alignItems: "center", gap: 14, flex: 1 }}>
              <div style={{
                width: 76, height: 76, borderRadius: "50%",
                background: "rgba(217,178,122,0.18)",
                border: "1px solid rgba(217,178,122,0.4)",
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
              }}>
                <Icon size={36} stroke="#d9b27a" strokeWidth={1.3} />
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: 0.2 }}>{label}</div>
                <div style={{ fontSize: 11, opacity: 0.6, marginTop: 2 }}>{hint}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 7 — Aerial Master Plan with pinned menu pucks
// ============================================================
const VariantMasterPlan = () => {
  // Synthesize a top-down master plan with SVG.
  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif", color: "#1c2520",
      background: "#e8e1cd",
    }}>
      {/* aerial */}
      <svg viewBox="0 0 1366 1024" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <defs>
          <pattern id="grass" width="6" height="6" patternUnits="userSpaceOnUse">
            <rect width="6" height="6" fill="#bbc89a"/>
            <circle cx="2" cy="2" r="0.6" fill="#7d9a5e" opacity="0.5"/>
            <circle cx="4" cy="4" r="0.5" fill="#7d9a5e" opacity="0.5"/>
          </pattern>
          <pattern id="trees" width="22" height="22" patternUnits="userSpaceOnUse">
            <circle cx="11" cy="11" r="6" fill="#6c8651"/>
            <circle cx="11" cy="11" r="3" fill="#557040" opacity="0.4"/>
          </pattern>
        </defs>

        {/* base */}
        <rect width="1366" height="1024" fill="#e8e1cd"/>

        {/* parkland */}
        <path d="M 60 60 L 1306 60 L 1306 964 L 60 964 Z" fill="url(#grass)" opacity="0.85"/>

        {/* tree clusters */}
        <ellipse cx="240" cy="200" rx="160" ry="100" fill="url(#trees)" opacity="0.8"/>
        <ellipse cx="1130" cy="220" rx="140" ry="90" fill="url(#trees)" opacity="0.8"/>
        <ellipse cx="200" cy="820" rx="170" ry="110" fill="url(#trees)" opacity="0.8"/>
        <ellipse cx="1140" cy="820" rx="150" ry="100" fill="url(#trees)" opacity="0.8"/>
        <ellipse cx="683" cy="512" rx="240" ry="160" fill="#9fb47a" opacity="0.5"/>

        {/* meandering paths */}
        <path d="M 60 512 Q 300 350 500 480 T 900 540 T 1306 460" stroke="#d3c79c" strokeWidth="14" fill="none"/>
        <path d="M 683 60 Q 600 300 700 500 T 800 800 T 683 964" stroke="#d3c79c" strokeWidth="14" fill="none"/>

        {/* central plaza */}
        <circle cx="683" cy="512" r="50" fill="#d3c79c"/>
        <circle cx="683" cy="512" r="32" fill="#bbc89a"/>

        {/* 10 towers - rectangles */}
        {[
          [380, 280], [520, 240], [820, 240], [960, 280],
          [300, 480], [1040, 480],
          [380, 740], [520, 780], [820, 780], [960, 740],
        ].map(([x, y], i) => (
          <g key={i}>
            <rect x={x - 26} y={y - 26} width="52" height="52" fill="#3a4a3a" opacity="0.92"/>
            <rect x={x - 22} y={y - 22} width="44" height="44" fill="none" stroke="#d9b27a" strokeWidth="1" opacity="0.7"/>
            <text x={x} y={y + 4} fill="#f4eedb" fontSize="11" textAnchor="middle" fontFamily="Inter, sans-serif" fontWeight="600">
              T{String(i + 1).padStart(2, "0")}
            </text>
          </g>
        ))}

        {/* clubhouse + pool */}
        <rect x="630" y="370" width="106" height="64" fill="#a85a32" opacity="0.85"/>
        <text x="683" y="406" fill="#fff" fontSize="11" textAnchor="middle" fontWeight="600" letterSpacing="2">CLUBHOUSE</text>
        <rect x="630" y="590" width="106" height="40" fill="#5a8db8" opacity="0.7"/>
        <text x="683" y="616" fill="#fff" fontSize="10" textAnchor="middle" letterSpacing="2">POOL</text>

        {/* perimeter road */}
        <rect x="60" y="60" width="1246" height="904" fill="none" stroke="#9c9883" strokeWidth="3" strokeDasharray="6 8"/>
      </svg>

      {/* tints & vignette */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(28,37,32,0.08), transparent 30%, transparent 70%, rgba(28,37,32,0.18))" }}/>

      <StatusBar />

      {/* top header overlay */}
      <div style={{
        position: "absolute", top: 50, left: 56, right: 56,
        display: "flex", justifyContent: "space-between", alignItems: "flex-start",
      }}>
        <div style={{
          background: "rgba(255,253,247,0.92)", backdropFilter: "blur(10px)",
          padding: "14px 22px", borderRadius: 12, display: "flex", alignItems: "center", gap: 14,
          boxShadow: "0 8px 24px rgba(28,37,32,0.08)",
        }}>
          <LivingTreeMark size={32} color="#2c4030" />
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, fontWeight: 500 }}>
              Living<em style={{ fontStyle: "italic", color: "#a85a32" }}>Tree</em>
            </div>
            <div style={{ fontSize: 10, letterSpacing: 2, opacity: 0.55, textTransform: "uppercase" }}>
              Master Plan · 25 acres · 10 towers
            </div>
          </div>
        </div>

        <div style={{
          background: "rgba(255,253,247,0.92)", backdropFilter: "blur(10px)",
          padding: "12px 18px", borderRadius: 12,
          fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", opacity: 0.8,
          boxShadow: "0 8px 24px rgba(28,37,32,0.08)",
        }}>
          <div style={{ opacity: 0.55, marginBottom: 2 }}>You are here →</div>
          <div style={{ fontWeight: 600, color: "#2c4030" }}>Sales Pavilion · Gate A</div>
        </div>
      </div>

      {/* corner pinned menu pucks */}
      {[
        { ...MENU_ITEMS[0], x: 175, y: 365, anchor: "tl" },  // floor plans → top-left towers
        { ...MENU_ITEMS[1], x: 1190, y: 470, anchor: "tr" }, // master plan → center
        { ...MENU_ITEMS[2], x: 175, y: 760, anchor: "bl" },  // location → road
        { ...MENU_ITEMS[3], x: 1190, y: 760, anchor: "br" }, // advantages → amenity
      ].map(({ key, label, hint, Icon, x, y }) => (
        <div key={key} style={{
          position: "absolute", left: x, top: y, transform: "translate(-50%, -50%)",
        }}>
          <div style={{
            width: 132, height: 132, borderRadius: "50%",
            background: "rgba(255,253,247,0.95)",
            backdropFilter: "blur(10px)",
            border: "1.5px solid rgba(44,64,48,0.2)",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            boxShadow: "0 16px 36px rgba(28,37,32,0.18)",
            position: "relative",
          }}>
            <Icon size={42} stroke="#2c4030" strokeWidth={1.3} />
            <div style={{ marginTop: 6, fontSize: 11, fontWeight: 600, letterSpacing: 0.4, textAlign: "center", maxWidth: 100 }}>
              {label}
            </div>
            {/* pin tail */}
            <div style={{
              position: "absolute", bottom: -8, left: "50%", transform: "translateX(-50%) rotate(45deg)",
              width: 16, height: 16, background: "rgba(255,253,247,0.95)",
              borderRight: "1.5px solid rgba(44,64,48,0.2)", borderBottom: "1.5px solid rgba(44,64,48,0.2)",
            }} />
          </div>
        </div>
      ))}

      {/* bottom info strip */}
      <div style={{
        position: "absolute", bottom: 28, left: 56, right: 56,
        background: "rgba(28,37,32,0.92)", color: "#f4eedb",
        padding: "16px 24px", borderRadius: 12,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        fontSize: 12, letterSpacing: 0.3,
      }}>
        <span><b>{PROJECT.config}</b> · {PROJECT.sizeFrom}–{PROJECT.sizeTo} sqft</span>
        <span><b style={{ color: "#d9b27a" }}>{PROJECT.priceFrom}</b> onwards</span>
        <span>{PROJECT.amen} amenities · {PROJECT.open} green</span>
        <span>Possession {PROJECT.poss}</span>
        <span style={{
          background: "#d9b27a", color: "#1c2520",
          padding: "8px 16px", borderRadius: 999, fontWeight: 600, fontSize: 12,
        }}>Book a walk-through →</span>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 8 — Magazine cover / table of contents
// ============================================================
const VariantMagazine = () => {
  const hero = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1100&q=80&auto=format&fit=crop";

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif",
      background: "#f6f1e3", color: "#1c2520",
    }}>
      <StatusBar />

      {/* paper texture */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: "radial-gradient(ellipse at top left, rgba(168,90,50,0.04), transparent 50%), radial-gradient(ellipse at bottom right, rgba(44,64,48,0.05), transparent 50%)",
      }}/>

      {/* masthead */}
      <div style={{
        position: "absolute", top: 48, left: 56, right: 56,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        paddingBottom: 20,
        borderBottom: "1px solid rgba(28,37,32,0.2)",
      }}>
        <div style={{ fontSize: 11, letterSpacing: 4, textTransform: "uppercase", opacity: 0.65 }}>
          Vol. 01 · Bagalur Edition · {PROJECT.poss} possession
        </div>
        <div style={{ fontSize: 11, letterSpacing: 4, textTransform: "uppercase", opacity: 0.65 }}>
          A residence by Kalyani Developers · est. {PROJECT.estd}
        </div>
      </div>

      {/* huge wordmark */}
      <div style={{
        position: "absolute", top: 102, left: 56, right: 56, textAlign: "center",
      }}>
        <div style={{
          fontFamily: "'Cormorant Garamond', serif", fontWeight: 500,
          fontSize: 156, lineHeight: 0.85, letterSpacing: -3,
        }}>
          Living<em style={{ fontStyle: "italic", color: "#a85a32" }}>Tree</em>
        </div>
      </div>

      {/* split */}
      <div style={{
        position: "absolute", top: 290, left: 56, right: 56, bottom: 120,
        display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56,
      }}>
        {/* hero photo column */}
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{
            flex: 1,
            backgroundImage: `url(${hero})`,
            backgroundSize: "cover", backgroundPosition: "center",
            position: "relative",
            boxShadow: "0 28px 50px rgba(28,37,32,0.18)",
          }}>
            <div style={{
              position: "absolute", left: -16, top: 24,
              background: "#a85a32", color: "#f6f1e3",
              padding: "10px 18px",
              fontSize: 11, letterSpacing: 3, textTransform: "uppercase", fontWeight: 600,
            }}>
              On the cover · 3 BHK · 1,639 sqft
            </div>
            <div style={{
              position: "absolute", left: 0, right: 0, bottom: 0,
              background: "linear-gradient(180deg, transparent, rgba(28,37,32,0.85))",
              padding: "30px 28px 24px", color: "#f6f1e3",
            }}>
              <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.85 }}>FEATURE · pp 12–28</div>
              <div style={{
                fontFamily: "'Cormorant Garamond', serif", fontSize: 30, fontStyle: "italic",
                marginTop: 6, lineHeight: 1.1,
              }}>
                A home with three open sides,<br/> and a courtyard for a grandmother.
              </div>
            </div>
          </div>
          <div style={{
            marginTop: 14, display: "flex", justifyContent: "space-between",
            fontSize: 10.5, letterSpacing: 2.5, textTransform: "uppercase", opacity: 0.55,
          }}>
            <span>Photography · A. Iyer</span>
            <span>Issue №01</span>
            <span>{PROJECT.acres} acres · {PROJECT.units} homes</span>
          </div>
        </div>

        {/* TOC column */}
        <div>
          <div style={{
            fontSize: 11, letterSpacing: 5, textTransform: "uppercase", opacity: 0.55,
            paddingBottom: 12, borderBottom: "1px solid rgba(28,37,32,0.15)",
          }}>
            Inside this issue
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 12 }}>
            {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => (
              <div key={key} style={{
                display: "flex", alignItems: "center", gap: 22, padding: "14px 6px",
                borderBottom: "1px solid rgba(28,37,32,0.08)",
              }}>
                <div style={{
                  width: 80, height: 80, borderRadius: "50%",
                  background: i === 0 ? "#2c4030" : "#fbf7e9",
                  color: i === 0 ? "#f6f1e3" : "#2c4030",
                  border: "1px solid rgba(44,64,48,0.15)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}>
                  <Icon size={36} strokeWidth={1.3} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{
                    fontSize: 10, letterSpacing: 3, textTransform: "uppercase", opacity: 0.5,
                  }}>
                    No. 0{i + 1} · pp {(i + 1) * 12}–{(i + 1) * 12 + 14}
                  </div>
                  <div style={{
                    fontFamily: "'Cormorant Garamond', serif", fontSize: 26, fontWeight: 500,
                    marginTop: 2, lineHeight: 1,
                  }}>
                    {label}
                  </div>
                  <div style={{ fontSize: 12, opacity: 0.6, marginTop: 4 }}>{hint}</div>
                </div>
                <div style={{
                  width: 36, height: 36, borderRadius: "50%",
                  border: "1px solid rgba(28,37,32,0.25)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 16, opacity: 0.6,
                }}>→</div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 18, fontSize: 11.5, opacity: 0.55, lineHeight: 1.5 }}>
            Editor's letter, the architect's plans, neighbourhood field-notes, and the case for trees. Tap a chapter to begin.
          </div>
        </div>
      </div>

      {/* footer barcode-ish */}
      <div style={{
        position: "absolute", bottom: 36, left: 56, right: 56,
        display: "flex", justifyContent: "space-between", alignItems: "flex-end",
        fontSize: 10.5, letterSpacing: 2.5, textTransform: "uppercase", opacity: 0.6,
      }}>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 16 }}>
          {/* fake barcode */}
          <div style={{ display: "flex", alignItems: "flex-end", gap: 1.5, height: 30 }}>
            {[3,1,2,1,4,1,2,3,1,2,1,3,2,1,4,1,2,1,3,1,2,3,1].map((w, i) => (
              <div key={i} style={{ width: w, height: "100%", background: "#1c2520" }}/>
            ))}
          </div>
          <span>RERA · 1251/309 · {PROJECT.estd}</span>
        </div>
        <span>From {PROJECT.priceFrom} · {PROJECT.config}</span>
        <span style={{ display: "flex", gap: 16 }}>
          <span>Schedule visit</span><span>·</span><span>Brochure</span><span>·</span><span>Sales: 1800-LIV-TREE</span>
        </span>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 9 — BHK Configurator: real-estate-app-first
// ============================================================
const VariantConfigurator = () => {
  const [activeBHK, setActiveBHK] = React.useState(1); // 2 BHK by default
  const bhk = BHK_DATA[activeBHK];

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif",
      background: "#fbfaf4", color: "#1c2520",
    }}>
      <StatusBar />

      {/* top */}
      <div style={{
        position: "absolute", top: 50, left: 56, right: 56,
        display: "flex", justifyContent: "space-between", alignItems: "center",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <LivingTreeMark size={36} color="#2c4030" />
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, fontWeight: 500 }}>
            Living<em style={{ fontStyle: "italic", color: "#a85a32" }}>Tree</em>
          </div>
          <span style={{ fontSize: 11, letterSpacing: 2, opacity: 0.5, textTransform: "uppercase", marginLeft: 6 }}>
            Bagalur · 15 min to KIA
          </span>
        </div>
        <div style={{
          padding: "10px 18px", background: "#e6f0d8", color: "#3a5e2a",
          borderRadius: 999, fontSize: 11, letterSpacing: 1.6, textTransform: "uppercase", fontWeight: 600,
        }}>
          ● Phase 1 · Now booking
        </div>
      </div>

      {/* BHK selector */}
      <div style={{ position: "absolute", top: 130, left: 56, right: 56 }}>
        <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.5, textTransform: "uppercase", marginBottom: 12 }}>
          Choose your configuration
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
          {BHK_DATA.map((b, i) => (
            <div key={b.tag} onClick={() => setActiveBHK(i)} style={{
              padding: "20px 24px", borderRadius: 14, cursor: "pointer",
              background: i === activeBHK ? "#2c4030" : "white",
              color: i === activeBHK ? "#fbfaf4" : "#1c2520",
              border: i === activeBHK ? "1px solid #2c4030" : "1px solid rgba(28,37,32,0.1)",
              boxShadow: i === activeBHK ? "0 16px 32px rgba(44,64,48,0.18)" : "0 4px 14px rgba(28,37,32,0.04)",
              transition: "all 0.2s",
            }}>
              <div style={{
                fontFamily: "'Cormorant Garamond', serif", fontSize: 32, fontWeight: 500, lineHeight: 1,
              }}>{b.tag}</div>
              <div style={{ marginTop: 8, fontSize: 12, opacity: i === activeBHK ? 0.75 : 0.55 }}>
                {b.size} sqft · {b.units}
              </div>
              <div style={{
                marginTop: 14, fontSize: 13, fontWeight: 600,
                color: i === activeBHK ? "#d9b27a" : "#a85a32",
              }}>
                {b.price}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* main row: title left, menu grid right */}
      <div style={{
        position: "absolute", top: 320, left: 56, right: 56, bottom: 140,
        display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 48,
      }}>
        {/* left — selected unit card */}
        <div style={{
          background: "linear-gradient(160deg, #2c4030 0%, #1c2c22 100%)",
          color: "#fbfaf4", borderRadius: 18, padding: 32,
          display: "flex", flexDirection: "column", justifyContent: "space-between",
          position: "relative", overflow: "hidden",
        }}>
          {/* leaf bg */}
          <svg style={{ position: "absolute", right: -40, bottom: -40, width: 360, height: 360, opacity: 0.12 }} viewBox="0 0 200 200">
            <path d="M40 160 C40 80 100 30 180 30 C180 110 130 160 40 160 Z" fill="#d9b27a"/>
          </svg>

          <div style={{ position: "relative" }}>
            <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.6, textTransform: "uppercase" }}>
              You are viewing
            </div>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif", fontSize: 80, fontWeight: 500, lineHeight: 0.9, marginTop: 14,
            }}>
              {bhk.tag}
            </div>
            <div style={{
              marginTop: 16, fontSize: 14, opacity: 0.8, lineHeight: 1.6,
            }}>
              {bhk.size} sq.ft · 3 sides open · with complimentary Juliet balcony · Vastu-compliant layout
            </div>
          </div>

          <div style={{ position: "relative" }}>
            <div style={{ display: "flex", gap: 28, marginBottom: 20 }}>
              <div>
                <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.55, textTransform: "uppercase" }}>Starting</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 500, color: "#d9b27a", marginTop: 4 }}>
                  {bhk.price.replace("from ", "")}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.55, textTransform: "uppercase" }}>Available</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 500, marginTop: 4 }}>
                  {bhk.units}
                </div>
              </div>
            </div>
            <button style={{
              background: "#d9b27a", color: "#1c2520", border: "none",
              padding: "14px 22px", borderRadius: 999, fontSize: 13, fontWeight: 600,
              letterSpacing: 0.4, cursor: "pointer",
            }}>Book {bhk.tag} site visit →</button>
          </div>
        </div>

        {/* right — 4 menu items as feature cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, gridTemplateRows: "1fr 1fr" }}>
          {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => (
            <div key={key} style={{
              background: "white", borderRadius: 16, padding: 22,
              border: "1px solid rgba(28,37,32,0.08)",
              boxShadow: "0 6px 20px rgba(28,37,32,0.05)",
              display: "flex", alignItems: "center", gap: 18,
            }}>
              <div style={{
                width: 96, height: 96, borderRadius: "50%",
                background: ["#f0e4d2", "#dfe7d2", "#e6d8d0", "#dde7d8"][i],
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}>
                <Icon size={42} stroke="#2c4030" strokeWidth={1.3} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.5, textTransform: "uppercase" }}>
                  Section 0{i + 1}
                </div>
                <div style={{ fontSize: 18, fontWeight: 600, marginTop: 2, letterSpacing: -0.1 }}>{label}</div>
                <div style={{ fontSize: 12, opacity: 0.6, marginTop: 4, lineHeight: 1.4 }}>{hint}</div>
                <div style={{ marginTop: 10, fontSize: 11, color: "#a85a32", fontWeight: 600, letterSpacing: 0.5 }}>
                  Open →
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* footer: progress bar */}
      <div style={{ position: "absolute", bottom: 36, left: 56, right: 56 }}>
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "center",
          fontSize: 11, letterSpacing: 2, textTransform: "uppercase", opacity: 0.6,
          marginBottom: 10,
        }}>
          <span>Construction progress · Phase 1</span>
          <span>Tower foundations · 38% complete · live as of today</span>
        </div>
        <div style={{ height: 6, background: "rgba(28,37,32,0.08)", borderRadius: 3, position: "relative" }}>
          <div style={{
            position: "absolute", left: 0, top: 0, bottom: 0, width: "38%",
            background: "linear-gradient(90deg, #2c4030, #d9b27a)", borderRadius: 3,
          }}/>
          {["Excavation", "Foundation", "Structure", "Finishing", "Possession"].map((s, i) => (
            <div key={s} style={{
              position: "absolute", left: `${i * 25}%`, top: -14, fontSize: 10,
              letterSpacing: 1.5, textTransform: "uppercase", opacity: 0.5,
              transform: i === 4 ? "translateX(-100%)" : "translateX(0)",
            }}>{s}</div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 10 — Warm hospitality / Apple-Store premium
// ============================================================
const VariantHospitality = () => {
  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif", color: "#2a201a",
      background: "linear-gradient(180deg, #f4ead6 0%, #ead9bc 100%)",
    }}>
      {/* wood-grain striping */}
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none", opacity: 0.08,
        backgroundImage: "repeating-linear-gradient(90deg, #6e4a26 0px, #6e4a26 1px, transparent 1px, transparent 3px), repeating-linear-gradient(90deg, transparent 0px, transparent 80px, rgba(110,74,38,0.12) 80px, rgba(110,74,38,0.12) 81px)",
      }} />

      <StatusBar />

      {/* huge brand at top */}
      <div style={{
        position: "absolute", top: 80, left: 0, right: 0, textAlign: "center",
      }}>
        <div style={{ fontSize: 11, letterSpacing: 8, opacity: 0.55, textTransform: "uppercase" }}>
          Welcome to the residence
        </div>
        <div style={{
          fontFamily: "'Cormorant Garamond', serif", fontWeight: 500,
          fontSize: 96, lineHeight: 0.95, letterSpacing: -2, marginTop: 14,
        }}>
          Living<em style={{ fontStyle: "italic", color: "#9a3a1a" }}>Tree</em>
        </div>
        <div style={{ marginTop: 14, fontSize: 13, letterSpacing: 4, opacity: 0.6, textTransform: "uppercase" }}>
          by Kalyani Developers · Bagalur, North Bengaluru
        </div>
      </div>

      {/* 4 large icons in row */}
      <div style={{
        position: "absolute", top: 380, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 76,
      }}>
        {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => (
          <div key={key} style={{ textAlign: "center", width: 200 }}>
            <div style={{
              width: 188, height: 188, borderRadius: "50%",
              background: "radial-gradient(circle at 35% 30%, #fdf6e4, #e9d6b3 75%, #d4b884)",
              border: "1px solid rgba(110,74,38,0.18)",
              display: "flex", alignItems: "center", justifyContent: "center",
              margin: "0 auto",
              boxShadow: "0 24px 50px rgba(110,74,38,0.18), inset 0 1px 0 rgba(255,255,255,0.6)",
            }}>
              <Icon size={70} stroke="#2c4030" strokeWidth={1.2} />
            </div>
            <div style={{ marginTop: 22, fontFamily: "'Cormorant Garamond', serif", fontSize: 24, fontWeight: 500, letterSpacing: 0.3 }}>{label}</div>
            <div style={{ marginTop: 4, fontSize: 12, opacity: 0.6 }}>{hint}</div>
          </div>
        ))}
      </div>

      {/* bottom row: appointment + amenities */}
      <div style={{
        position: "absolute", bottom: 60, left: 56, right: 56,
        display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 28, alignItems: "center",
      }}>
        {/* appointment chip */}
        <div style={{
          background: "rgba(255,253,247,0.85)", backdropFilter: "blur(10px)",
          padding: "16px 22px 16px 16px", borderRadius: 999,
          display: "flex", alignItems: "center", gap: 14,
          border: "1px solid rgba(110,74,38,0.15)",
          boxShadow: "0 8px 24px rgba(110,74,38,0.08)",
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: "50%",
            background: "linear-gradient(135deg, #c7895c, #9a5a2e)",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fdf6e4", fontWeight: 600, fontSize: 14,
          }}>RK</div>
          <div style={{ lineHeight: 1.2 }}>
            <div style={{ fontSize: 11, letterSpacing: 2.5, opacity: 0.55, textTransform: "uppercase" }}>
              Today · 2:30 PM
            </div>
            <div style={{ fontSize: 15, fontWeight: 600 }}>Mr. Rohit Kapoor · 3 BHK tour</div>
          </div>
        </div>

        {/* divider quote */}
        <div style={{ textAlign: "center", padding: "0 18px" }}>
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontSize: 19, fontStyle: "italic",
            opacity: 0.7, lineHeight: 1.3,
          }}>
            “{PROJECT.acres} acres · {PROJECT.amen} amenities · two clubhouses · 80% open · from {PROJECT.priceFrom}”
          </div>
        </div>

        {/* CTA */}
        <button style={{
          background: "#2c4030", color: "#fdf6e4", border: "none",
          padding: "18px 28px", borderRadius: 999, fontSize: 14, fontWeight: 600,
          letterSpacing: 0.5, cursor: "pointer",
          boxShadow: "0 12px 28px rgba(44,64,48,0.25)",
        }}>Begin the tour →</button>
      </div>

      {/* tiny RERA at bottom */}
      <div style={{
        position: "absolute", bottom: 18, left: 0, right: 0, textAlign: "center",
        fontSize: 9.5, letterSpacing: 2, opacity: 0.45,
      }}>
        RERA · {PROJECT.rera} · {PROJECT.units} homes · Possession {PROJECT.poss}
      </div>
    </div>
  );
};

Object.assign(window, {
  VariantConsole, VariantTowers, VariantMasterPlan,
  VariantMagazine, VariantConfigurator, VariantHospitality,
  PROJECT,
});
