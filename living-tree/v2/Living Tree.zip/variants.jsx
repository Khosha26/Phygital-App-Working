// Four variations of the Living Tree home screen.
// Tablet frame: iPad Pro landscape 1366×1024.

const TABLET_W = 1366;
const TABLET_H = 1024;

// ============================================================
// Shared bits
// ============================================================
const StatusBar = ({ light = false, time = "10:42" }) => {
  const color = light ? "rgba(255,255,255,0.92)" : "rgba(30,38,32,0.85)";
  return (
    <div style={{
      position: "absolute", top: 0, left: 0, right: 0, height: 28,
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "0 28px", fontFamily: "Inter, sans-serif", fontSize: 12,
      letterSpacing: 0.4, color, zIndex: 10, fontWeight: 500,
    }}>
      <span>{time}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{ opacity: 0.85 }}>Sales Gallery · Tablet 04</span>
        <span style={{ width: 4, height: 4, borderRadius: "50%", background: color, opacity: 0.4 }} />
        <span>100%</span>
        <span style={{ width: 22, height: 11, border: `1px solid ${color}`, borderRadius: 2, position: "relative", marginLeft: 2 }}>
          <span style={{ position: "absolute", inset: 1.5, background: color, borderRadius: 1 }} />
        </span>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 1 — Botanical hero, glass tiles arranged horizontally
// ============================================================
const VariantBotanical = () => {
  const bg = "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=1600&q=80&auto=format&fit=crop";

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif", color: "#f6f1e7",
      background: "#0f1a14",
    }}>
      {/* hero image */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `url(${bg})`,
        backgroundSize: "cover", backgroundPosition: "center",
        filter: "saturate(0.85) brightness(0.75)",
      }} />
      {/* vignette + gradient overlay */}
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, rgba(15,26,20,0.55) 0%, rgba(15,26,20,0.25) 35%, rgba(15,26,20,0.85) 100%)",
      }} />
      <StatusBar light />

      {/* top bar — brand */}
      <div style={{
        position: "absolute", top: 56, left: 56, right: 56,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <LivingTreeMark size={42} color="#f6f1e7" />
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, fontWeight: 500, letterSpacing: 0.5 }}>
              Living Tree
            </div>
            <div style={{ fontSize: 10.5, letterSpacing: 3, opacity: 0.7, marginTop: 4, textTransform: "uppercase" }}>
              by Kalyani Developers
            </div>
          </div>
        </div>
        <div style={{
          display: "flex", alignItems: "center", gap: 14, fontSize: 12, letterSpacing: 1.5,
          textTransform: "uppercase", opacity: 0.85,
        }}>
          <span style={{
            padding: "8px 16px", border: "1px solid rgba(246,241,231,0.35)", borderRadius: 999,
          }}>RERA · KA/RERA/1251/308</span>
          <span style={{
            padding: "8px 16px", border: "1px solid rgba(246,241,231,0.35)", borderRadius: 999,
          }}>EN · हिन्दी · ಕನ್ನಡ</span>
        </div>
      </div>

      {/* center title */}
      <div style={{
        position: "absolute", top: 195, left: 0, right: 0, textAlign: "center",
      }}>
        <div style={{
          fontSize: 11, letterSpacing: 6, opacity: 0.7, textTransform: "uppercase", marginBottom: 18,
        }}>
          Sarjapur Road · 8.4 acres · 3 towers
        </div>
        <h1 style={{
          fontFamily: "'Cormorant Garamond', serif", fontWeight: 400,
          fontSize: 88, lineHeight: 1, margin: 0, letterSpacing: -1,
        }}>
          A home, <em style={{ fontStyle: "italic", color: "#d9b27a" }}>rooted</em>.
        </h1>
        <div style={{ marginTop: 22, fontSize: 15, opacity: 0.75, letterSpacing: 0.2 }}>
          Tap any circle to explore the residence.
        </div>
      </div>

      {/* menu row */}
      <div style={{
        position: "absolute", bottom: 130, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 52,
      }}>
        {MENU_ITEMS.map(({ key, label, hint, Icon }) => (
          <div key={key} style={{ textAlign: "center", width: 180 }}>
            <div style={{
              width: 168, height: 168, borderRadius: "50%",
              background: "rgba(255,255,255,0.08)",
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
              border: "1px solid rgba(246,241,231,0.28)",
              display: "flex", alignItems: "center", justifyContent: "center",
              margin: "0 auto",
              boxShadow: "0 20px 50px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.15)",
            }}>
              <Icon size={62} stroke="#f6f1e7" strokeWidth={1.3} />
            </div>
            <div style={{ marginTop: 18, fontSize: 17, fontWeight: 500, letterSpacing: 0.3 }}>{label}</div>
            <div style={{ marginTop: 4, fontSize: 12, opacity: 0.65, letterSpacing: 0.3 }}>{hint}</div>
          </div>
        ))}
      </div>

      {/* bottom strip */}
      <div style={{
        position: "absolute", bottom: 36, left: 56, right: 56,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        fontSize: 11.5, letterSpacing: 1.8, textTransform: "uppercase", opacity: 0.7,
      }}>
        <span>Possession · Dec 2027</span>
        <span style={{ display: "flex", gap: 24 }}>
          <span>Brochure</span><span>Site Visit</span><span>Talk to Sales</span>
        </span>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 2 — Ivory editorial, icons in 2×2 grid beside hero
// ============================================================
const VariantEditorial = () => {
  const hero = "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=1200&q=80&auto=format&fit=crop";

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif",
      background: "#f3ede0",
      color: "#1f2a22",
    }}>
      <StatusBar />

      {/* top bar */}
      <div style={{
        position: "absolute", top: 50, left: 64, right: 64,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <LivingTreeMark size={36} color="#2c4030" />
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontSize: 26, letterSpacing: 0.4, fontWeight: 500,
          }}>Living Tree</div>
        </div>
        <div style={{ display: "flex", gap: 28, fontSize: 11.5, letterSpacing: 2, textTransform: "uppercase", opacity: 0.6 }}>
          <span>Gallery</span><span>Brochure</span><span style={{ fontWeight: 600, color: "#2c4030" }}>Home</span><span>Sales</span>
        </div>
      </div>

      {/* main split */}
      <div style={{
        position: "absolute", top: 130, left: 64, right: 64, bottom: 90,
        display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56,
      }}>
        {/* left — hero image w/ caption */}
        <div style={{ position: "relative", display: "flex", flexDirection: "column" }}>
          <div style={{
            flex: 1, borderRadius: 4,
            backgroundImage: `url(${hero})`,
            backgroundSize: "cover", backgroundPosition: "center",
            boxShadow: "0 30px 60px rgba(40,52,42,0.18)",
            position: "relative",
          }}>
            <div style={{
              position: "absolute", left: 0, bottom: 0, right: 0, padding: "24px 28px",
              background: "linear-gradient(180deg, transparent, rgba(15,26,20,0.7))",
              color: "#f6f1e7", borderRadius: "0 0 4px 4px",
            }}>
              <div style={{ fontSize: 10, letterSpacing: 3, opacity: 0.8, textTransform: "uppercase" }}>Volume I</div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, marginTop: 4, fontStyle: "italic" }}>
                Where the canopy meets the courtyard.
              </div>
            </div>
          </div>
          <div style={{
            marginTop: 20, display: "flex", justifyContent: "space-between",
            fontSize: 11, letterSpacing: 2, textTransform: "uppercase", opacity: 0.55,
          }}>
            <span>Plot · 8.4 acres</span>
            <span>Open · 72%</span>
            <span>Trees · 320+</span>
          </div>
        </div>

        {/* right — title + 2x2 menu grid */}
        <div style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.55, textTransform: "uppercase" }}>
            Living Tree · Phase 1
          </div>
          <h1 style={{
            fontFamily: "'Cormorant Garamond', serif", fontWeight: 400,
            fontSize: 64, lineHeight: 1.02, margin: "10px 0 6px", letterSpacing: -0.5,
          }}>
            Choose your<br/>
            <em style={{ fontStyle: "italic", color: "#a85a32" }}>way in.</em>
          </h1>
          <div style={{ fontSize: 14, opacity: 0.6, maxWidth: 360, lineHeight: 1.5, marginBottom: 36 }}>
            Four doorways into the residence. Tap any circle to walk through it with your sales partner.
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 28, maxWidth: 460 }}>
            {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => (
              <div key={key} style={{ display: "flex", alignItems: "center", gap: 18 }}>
                <div style={{
                  width: 96, height: 96, borderRadius: "50%",
                  background: i === 0 ? "#2c4030" : "#fbf7ee",
                  color: i === 0 ? "#f6f1e7" : "#2c4030",
                  border: "1px solid rgba(44,64,48,0.18)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                  boxShadow: i === 0 ? "0 14px 28px rgba(44,64,48,0.28)" : "0 10px 22px rgba(44,64,48,0.08)",
                }}>
                  <Icon size={42} strokeWidth={1.3} />
                </div>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: 0.2 }}>{label}</div>
                  <div style={{ fontSize: 11.5, opacity: 0.55, marginTop: 2 }}>{hint}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* footer */}
      <div style={{
        position: "absolute", bottom: 36, left: 64, right: 64,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        fontSize: 11, letterSpacing: 2, textTransform: "uppercase", opacity: 0.5,
      }}>
        <span>Kalyani Developers</span>
        <span>RERA · KA/RERA/1251/308</span>
        <span>Possession Dec 2027</span>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 3 — Compass: icons on a circle, brand mark center
// ============================================================
const VariantCompass = () => {
  const photos = [
    "https://images.unsplash.com/photo-1448630360428-65456885c650?w=900&q=80&auto=format&fit=crop", // floor / interior
    "https://images.unsplash.com/photo-1480074568708-e7b720bb3f09?w=900&q=80&auto=format&fit=crop", // master plan aerial
    "https://images.unsplash.com/photo-1449034446853-66c86144b0ad?w=900&q=80&auto=format&fit=crop", // location
    "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=900&q=80&auto=format&fit=crop", // advantages
  ];

  // 4 points on a circle, top / right / bottom / left
  const R = 290;
  const positions = [
    { x: 0, y: -R, label: "top" },
    { x: R, y: 0, label: "right" },
    { x: 0, y: R, label: "bottom" },
    { x: -R, y: 0, label: "left" },
  ];

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif",
      background: "radial-gradient(ellipse at 50% 40%, #1a2a20 0%, #0c1610 70%, #070d09 100%)",
      color: "#f1ead8",
    }}>
      {/* subtle texture rings */}
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.18 }}>
        <defs>
          <radialGradient id="ringFade" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#d9b27a" stopOpacity="0.5"/>
            <stop offset="100%" stopColor="#d9b27a" stopOpacity="0"/>
          </radialGradient>
        </defs>
        {[180, 240, 300, 360, 420].map(r => (
          <circle key={r} cx="50%" cy="52%" r={r} fill="none" stroke="url(#ringFade)" strokeWidth="0.6" strokeDasharray="2 6"/>
        ))}
      </svg>

      <StatusBar light />

      {/* top brand */}
      <div style={{
        position: "absolute", top: 56, left: 0, right: 0,
        display: "flex", justifyContent: "center",
      }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 10.5, letterSpacing: 6, opacity: 0.55, textTransform: "uppercase" }}>
            Kalyani Developers · Est. 1995
          </div>
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontSize: 36, fontWeight: 500,
            letterSpacing: 1.5, marginTop: 6,
          }}>
            LIVING&nbsp;&nbsp;TREE
          </div>
        </div>
      </div>

      {/* compass */}
      <div style={{
        position: "absolute", top: "50%", left: "50%",
        transform: "translate(-50%, calc(-50% + 30px))",
        width: 1, height: 1,
      }}>
        {/* center */}
        <div style={{
          position: "absolute", left: "50%", top: "50%",
          transform: "translate(-50%, -50%)",
          width: 240, height: 240, borderRadius: "50%",
          background: "radial-gradient(circle at 40% 35%, #29402f 0%, #1a2a20 65%, #11201a 100%)",
          border: "1px solid rgba(217,178,122,0.35)",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          boxShadow: "inset 0 0 60px rgba(217,178,122,0.08), 0 30px 80px rgba(0,0,0,0.5)",
        }}>
          <LivingTreeMark size={64} color="#d9b27a" strokeWidth={1.2} />
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
            fontSize: 22, marginTop: 12, color: "#d9b27a",
          }}>est. here</div>
          <div style={{
            fontSize: 9.5, letterSpacing: 4, marginTop: 6, opacity: 0.6, textTransform: "uppercase",
          }}>Sarjapur · 12.97°N</div>
        </div>

        {/* 4 satellite tiles */}
        {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => {
          const p = positions[i];
          return (
            <div key={key} style={{
              position: "absolute", left: "50%", top: "50%",
              transform: `translate(calc(-50% + ${p.x}px), calc(-50% + ${p.y}px))`,
              textAlign: "center", width: 200,
            }}>
              {/* connector line */}
              <svg style={{
                position: "absolute", left: "50%", top: "50%",
                transform: "translate(-50%, -50%)",
                width: R * 2, height: R * 2, pointerEvents: "none",
                zIndex: 0,
              }}>
                <line
                  x1={R} y1={R}
                  x2={R - p.x} y2={R - p.y}
                  stroke="rgba(217,178,122,0.18)" strokeWidth="1" strokeDasharray="3 4"
                />
              </svg>
              <div style={{
                position: "relative", zIndex: 1,
                width: 156, height: 156, borderRadius: "50%", margin: "0 auto",
                backgroundImage: `linear-gradient(180deg, rgba(15,26,20,0.4), rgba(15,26,20,0.75)), url(${photos[i]})`,
                backgroundSize: "cover", backgroundPosition: "center",
                border: "1px solid rgba(217,178,122,0.45)",
                display: "flex", alignItems: "center", justifyContent: "center",
                boxShadow: "0 18px 40px rgba(0,0,0,0.5)",
              }}>
                <Icon size={56} stroke="#f1ead8" strokeWidth={1.3} />
              </div>
              <div style={{
                marginTop: 14, fontSize: 13, letterSpacing: 3, textTransform: "uppercase", fontWeight: 500,
              }}>{label}</div>
              <div style={{ marginTop: 4, fontSize: 11, opacity: 0.55 }}>{hint}</div>
            </div>
          );
        })}
      </div>

      {/* bottom plate */}
      <div style={{
        position: "absolute", bottom: 30, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 40,
        fontSize: 10.5, letterSpacing: 3, textTransform: "uppercase", opacity: 0.5,
      }}>
        <span>Phase 1 · Now Open</span>
        <span>·</span>
        <span>3 Towers · 412 Homes</span>
        <span>·</span>
        <span>Possession Dec 2027</span>
      </div>
    </div>
  );
};

// ============================================================
// VARIANT 4 — Full-bleed canopy, icons floating across the bottom
// like stepping stones, with curated "moment" cards above
// ============================================================
const VariantCanopy = () => {
  const canopy = "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1600&q=80&auto=format&fit=crop";

  return (
    <div style={{
      width: TABLET_W, height: TABLET_H, position: "relative", overflow: "hidden",
      fontFamily: "Inter, sans-serif",
      background: "#0e1612", color: "#fbf6e9",
    }}>
      {/* canopy */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `url(${canopy})`,
        backgroundSize: "cover", backgroundPosition: "center 30%",
        filter: "saturate(0.7) brightness(0.55) hue-rotate(-5deg)",
      }} />
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, rgba(14,22,18,0.45) 0%, rgba(14,22,18,0.15) 30%, rgba(14,22,18,0.55) 65%, rgba(14,22,18,0.95) 100%)",
      }} />

      <StatusBar light />

      {/* top brand row */}
      <div style={{
        position: "absolute", top: 56, left: 64, right: 64,
        display: "flex", justifyContent: "space-between", alignItems: "flex-start",
      }}>
        <div>
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontSize: 44, fontWeight: 500, letterSpacing: 0.6,
            lineHeight: 1,
          }}>
            Living&nbsp;<em style={{ fontStyle: "italic", color: "#d9b27a" }}>Tree</em>
          </div>
          <div style={{ fontSize: 10.5, letterSpacing: 4, opacity: 0.65, marginTop: 8, textTransform: "uppercase" }}>
            A Kalyani Developers Residence · Sarjapur, Bengaluru
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          {["EN", "हिं", "ಕ"].map((s, i) => (
            <span key={s} style={{
              width: 38, height: 38, borderRadius: "50%",
              border: "1px solid rgba(251,246,233,0.3)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 13, fontWeight: 500,
              background: i === 0 ? "rgba(251,246,233,0.12)" : "transparent",
            }}>{s}</span>
          ))}
        </div>
      </div>

      {/* hero quote */}
      <div style={{
        position: "absolute", top: 215, left: 64, right: 64, textAlign: "left",
        maxWidth: 720,
      }}>
        <div style={{ fontSize: 11, letterSpacing: 5, opacity: 0.6, textTransform: "uppercase", marginBottom: 14 }}>
          Welcome ·  Mr. & Mrs. Iyer
        </div>
        <div style={{
          fontFamily: "'Cormorant Garamond', serif", fontSize: 56, lineHeight: 1.05,
          fontWeight: 400, letterSpacing: -0.3,
        }}>
          “The first tree was planted on this site in <em style={{ fontStyle: "italic", color: "#d9b27a" }}>1971</em>.
          Three generations later, it still holds the courtyard.”
        </div>
        <div style={{ marginTop: 22, fontSize: 12.5, letterSpacing: 2, opacity: 0.65, textTransform: "uppercase" }}>
          — From the architect's note
        </div>
      </div>

      {/* stat strip on the right */}
      <div style={{
        position: "absolute", top: 215, right: 64, width: 240,
        display: "flex", flexDirection: "column", gap: 20,
        borderLeft: "1px solid rgba(251,246,233,0.18)",
        paddingLeft: 28,
      }}>
        {[
          ["8.4", "acres of green"],
          ["72%", "open spaces"],
          ["3", "residential towers"],
          ["412", "curated homes"],
          ["2027", "possession"],
        ].map(([n, l]) => (
          <div key={l}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 34, fontWeight: 500, lineHeight: 1 }}>{n}</div>
            <div style={{ fontSize: 11, letterSpacing: 2, opacity: 0.6, textTransform: "uppercase", marginTop: 4 }}>{l}</div>
          </div>
        ))}
      </div>

      {/* stepping stones — icons along the bottom */}
      <div style={{
        position: "absolute", bottom: 64, left: 64, right: 64,
      }}>
        <div style={{
          fontSize: 10.5, letterSpacing: 5, opacity: 0.55, textTransform: "uppercase",
          marginBottom: 20, display: "flex", alignItems: "center", gap: 14,
        }}>
          <span style={{ width: 28, height: 1, background: "rgba(251,246,233,0.4)" }} />
          Step in
        </div>
        <div style={{ display: "flex", gap: 22, alignItems: "flex-start" }}>
          {MENU_ITEMS.map(({ key, label, hint, Icon }, i) => (
            <div key={key} style={{
              flex: 1,
              display: "flex", alignItems: "center", gap: 18,
              padding: "18px 22px",
              borderRadius: 999,
              background: i === 0
                ? "linear-gradient(135deg, rgba(217,178,122,0.95), rgba(196,148,88,0.88))"
                : "rgba(251,246,233,0.08)",
              border: i === 0 ? "1px solid rgba(217,178,122,0.5)" : "1px solid rgba(251,246,233,0.18)",
              backdropFilter: "blur(14px)",
              WebkitBackdropFilter: "blur(14px)",
              color: i === 0 ? "#1a2a20" : "#fbf6e9",
            }}>
              <div style={{
                width: 64, height: 64, borderRadius: "50%",
                background: i === 0 ? "#fbf6e9" : "rgba(251,246,233,0.1)",
                border: i === 0 ? "none" : "1px solid rgba(251,246,233,0.25)",
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}>
                <Icon size={32} stroke={i === 0 ? "#1a2a20" : "#fbf6e9"} strokeWidth={1.4} />
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: 0.3 }}>{label}</div>
                <div style={{ fontSize: 11, opacity: i === 0 ? 0.7 : 0.55, marginTop: 3 }}>{hint}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, {
  VariantBotanical, VariantEditorial, VariantCompass, VariantCanopy,
  TABLET_W, TABLET_H,
});
